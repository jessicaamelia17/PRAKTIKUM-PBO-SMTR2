public class Mahasiswa {
    public String nim;
    public String nama;
    public String alamat;
    public String kelas;

    public void displayBiodata(){
        System.out.println("Nim     :" + nim);
        System.out.println("Nama    :" + nama);
        System.out.println("Alamat  :" + alamat);
        System.out.println("Kelas   :" + kelas);
        System.out.println();
    }
}
